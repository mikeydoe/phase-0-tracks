class Dancer

	dancer = "Misty Copeland"
	age = 33

	def pirouette

		puts "*twirls*"
	end
end


d = Dancer.new

d.age
d.dancer
d.pirouette